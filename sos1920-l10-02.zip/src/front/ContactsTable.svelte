<script>
	let contacts = [];

	async function getContacts() {

		const res = await fetch("/api/v1/contacts");
		console.log("Fetching contacts...");

		if (res.ok) {
			console.log("Ok:");
			const json = await res.json();
			contacts = json;
			console.log("Received " + contacts.length + " contacts.");
		} else {
			console.log("ERROR!");
		}
	}

	console.log("Before getContacts()");
	getContacts();
	console.log("After getContacts()");
</script>

<main>

	{#await contacts}
	{:then contacts}

		<table>
			<thead>
				<tr>
					<td>Name</td>
					<td>Email</td>
					<td>Phone</td>
				</tr>
			</thead>
			<tbody>
				{#each contacts as contact}
					<tr>
						<td>{contact.name}</td>
						<td>{contact.email}</td>
						<td>{contact.phone}</td>
					</tr>
				{/each}
			</tbody>
		</table>
	{/await}


</main>

<style>
	table {
		border: 1px solid black;
	}
</style>