<script>
	import ContactsTable from './ContactsTable.svelte';
</script>

<main>
	<ContactsTable />
</main>